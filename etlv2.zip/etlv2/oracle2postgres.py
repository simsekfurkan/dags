from airflow import DAG
from airflow.providers.jdbc.hooks.jdbc import JdbcHook
from airflow.operators.python_operator import PythonOperator
from datetime import datetime

def transfer_data():
    oracle_conn_id = 'oracle_jdbc'
    postgres_conn_id = 'postgres_jdbc'

    # Oracle'dan veri çek
    oracle_hook = JdbcHook(jdbc_conn_id=oracle_conn_id)
    source_query = "SELECT * FROM IHOPE_DEPSAS.UYAP_DOSYA"
    source_records = oracle_hook.get_records(sql=source_query)

    # PostgreSQL'e veri yükle
    postgres_hook = JdbcHook(jdbc_conn_id=postgres_conn_id)
    target_table = 'ods_hope_depsas.uyap_dosya'

    # Her satýrý eklemek için bir SQL INSERT sorgusu oluþtur
    insert_query = f"INSERT INTO {target_table} VALUES ({', '.join(['%s'] * len(source_records[0]))})"

    for record in source_records:
        postgres_hook.run(insert_query, parameters=record)

default_args = {
    'owner': 'airflow',
    'start_date': datetime(2023, 1, 1),
    'retries': 1,
}

dag = DAG(
    'oracle_to_postgres_jdbc_direct',
    default_args=default_args,
    description='Transfer data from Oracle to PostgreSQL using JDBC directly',
    schedule_interval='@daily',
)

transfer_data_task = PythonOperator(
    task_id='transfer_data',
    python_callable=transfer_data,
    dag=dag,
)

transfer_data_task
