import subprocess
from psycopg import connect, sql
import csv
import sys
import cx_Oracle
import logging
import os
import pandas as pd
import json

def export_to_csv(oracle_connection_string, schema_name, table_name, csv_folder, db_details):
    # Oracle veritabanýna baðlan
    connection = cx_Oracle.connect(oracle_connection_string)
    cursor = connection.cursor()

    try:
        # Kolon adlarýný çek
        column_names = get_column_names(cursor, schema_name, table_name)

        # CSV dosyasýnýn adýný belirle
        table_config = db_details["tables"].get(table_name)
        if table_config and "new_name" in table_config:
            csv_file_name = table_config["new_name"]
        else:
            csv_file_name = table_name.lower()

        # CSV dosyasýnýn tam yolunu oluþtur
        csv_file_path = f'{csv_folder}/{csv_file_name}.csv'

        # Kolon adlarýný birleþtir
        columns_concatenated = " || '~' || ".join(column_names)

                # SQL sorgusunu oluþtur
        sql_part1 = (
            f'SET ECHO OFF\n'
            f'SET TERMOUT OFF\n'
            f'SET FEEDBACK OFF\n'
            f'SET TRIMSPOOL OFF\n'
            f'SET ARRAYSIZE 20000\n'
            f'SET VERIFY OFF\n'
            f'SET PAGESIZE 0\n'
            f'SET HEADING OFF\n'
            f'SET MARKUP CSV ON DELIMITER ~\n'
            f'SPOOL {csv_file_path}\n'
        )
        sql_part2 = f'SELECT * FROM {schema_name}.{table_name};\n'
        sql_part3 = f'SPOOL OFF\n'

        # SQL sorgusunu birleþtir
        sql_query = sql_part1 + sql_part2 + sql_part3

        # SQL*Plus komutunu oluþtur ve çalýþtýr
        sqlplus_command = f'sqlplus -S {oracle_connection_string}'
        os.system(f'echo "{sql_query}" | {sqlplus_command}')

        print(f'{table_name} tablosu {csv_file_name}.csv dosyasýna aktarýldý.')

    finally:
        # Cursor ve baðlantýyý kapat
        cursor.close()
        connection.close()

def get_column_names(cursor, schema_name, table_name):
    # Kolon adlarýný çek
    query = f"SELECT column_name FROM all_tab_columns WHERE table_name = '{table_name}' AND owner = '{schema_name}'"
    cursor.execute(query)
    column_names = [row[0] for row in cursor.fetchall()]
    return column_names


def copy_csv_to_postgresql(csv_file_path, conn_string, schema_name, table_name):
    """Imports data from a CSV file to PostgreSQL using COPY FROM STDIN with CSV formatting."""
    with connect(conn_string) as conn:
        with conn.cursor() as cursor:
            try:

                # Prepare the COPY command with NULL handling
                # Assuming 'NULL' is the placeholder in your CSV file for null values
                copy_sql = sql.SQL("COPY {}.{} FROM STDIN WITH (FORMAT csv, DELIMITER '~', QUOTE '\"', ESCAPE '\\')").format(
                    sql.Identifier(schema_name), 
                    sql.Identifier(table_name.lower()))

                # Open the CSV file and execute the COPY command
                with open(csv_file_path, 'r', newline='') as f:
                    with cursor.copy(copy_sql) as copy:
                        # Read the file and stream it to the database
                        copy.write(f.read())
                    conn.commit()
                    logging.info(f"Data copied successfully from {csv_file_path} to {schema_name}.{table_name.lower()}.")

            except Exception as e:
                logging.error(f"Error during copying data: {e}")
                conn.rollback()
                raise
