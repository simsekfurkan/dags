from datetime import datetime
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import oracledb
import psycopg
import pyodbc
import pyarrow.dataset as ds
from pgpq import ArrowToPostgresBinaryEncoder
import numpy as np
import logging
import cx_Oracle
from psycopg.rows import dict_row
import psycopg2.extras
import psycopg2
import polars as pl
import time
from airflow.hooks.base_hook import BaseHook
import os


# Loglama yapýlandýrmasý
logging.basicConfig(level=logging.DEBUG)

def get_column_types(sql_conn, schema_name, table_name):
    query = f"""
    SELECT COLUMN_NAME, DATA_TYPE
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = '{schema_name}' AND TABLE_NAME = '{table_name}';
    """
    logging.debug(f"Running schema query: {query}")
    return pd.read_sql(query, sql_conn)

def fetch_data_from_sqlserver(db_config, table_name):
    # Airflow Connection'ýndan baðlantý bilgilerini al
    conn = BaseHook.get_connection(db_config['connection_id'])
    
    # Connection string oluþtur
    conn_str = f"""
        DRIVER={{ODBC Driver 17 for SQL Server}};
        SERVER={db_config['server']},{conn.port};
        DATABASE={db_config['database']};
        UID={conn.login};
        PWD={conn.password};
        TrustServerCertificate=No;
    """
    logging.debug(f"Connecting to SQL Server using: {conn_str}")
    
    # SQL Server'a baðlan
    sql_conn = pyodbc.connect(conn_str)
    logging.info("Connected to SQL Server successfully.")

    custom_sql = db_config['tables'][table_name].get('custom_sql')

    if custom_sql:
        currentYearMonth = datetime.now().strftime('%Y%m')
        dynamic_table_name = f"{db_config['schema_name']}.TKI_INTERVAL_DATA_{currentYearMonth}"
        startDate = datetime.now().replace(day=1, hour=0, minute=0, second=0, microsecond=0).strftime('%Y-%m-%d %H:%M:%S')
        sql = custom_sql.format(table_name=dynamic_table_name, startDate=startDate)
    else:
        sql = f"SELECT   * FROM {db_config['schema_name']}.{table_name} "

    logging.debug(f"Executing SQL query: {sql}")

    # Ýþlem baþlamadan önce zamaný kaydedin
    start_time = time.time()

    # SQL sorgusunu çalýþtýr ve veriyi DataFrame'e yükle
    df = pd.read_sql(sql, con=sql_conn)

    # Sütun adý eþleþtirmesi uygula
    column_mapping = db_config['tables'][table_name].get('column_mapping', {})
    df.rename(columns=column_mapping, inplace=True)

    # Ýþlem bittikten sonra geçen zamaný hesaplayýn
    end_time = time.time()
    elapsed_time = end_time - start_time

    # Veri aktarým oranýný hesaplayýn
    row_count = len(df)
    transfer_rate = row_count / elapsed_time  # Satýr/saniye cinsinden

    # Loglama: Veri aktarým oranýný ve aktarýlan satýr sayýsýný yazdýrýn
    logging.info(f"Retrieved {row_count} rows from table {table_name}. Transfer rate: {transfer_rate:.2f} rows/sec.")

    # Baðlantýyý kapat
    sql_conn.close()
    logging.info("Database connection closed.")

    return df

def fetch_data_from_oracle(db_config, table_name):
    # Airflow Connection'ýndan baðlantý bilgilerini al
    conn = BaseHook.get_connection(db_config['connection_id'])
    
    # Baðlantý bilgilerini kullanarak Oracle baðlantýsý oluþtur
    dsn = f"{conn.host}:{conn.port}/{conn.schema}"
    oracle_conn = oracledb.connect(user=conn.login, password=conn.password, dsn=dsn)

    # Tablo adýný kullanarak sorguyu oluþtur
    schema_name = db_config.get('schema_name', 'default_schema')
    custom_sql = db_config.get('tables', {}).get(table_name, {}).get('custom_sql')
    
    if custom_sql:
        currentYearMonth = datetime.now().strftime('%Y%m')
        dynamic_table_name = f"{schema_name}.TKI_INTERVAL_DATA_{currentYearMonth}"
        startDate = datetime.now().replace(day=1, hour=0, minute=0, second=0, microsecond=0).strftime('%Y-%m-%d %H:%M:%S')
        sql = custom_sql.format(table_name=dynamic_table_name, startDate=startDate)
    else:
        sql = f"SELECT * FROM {schema_name}.{table_name}"
    
    # Veritabanýndan veri çek
    cursor = oracle_conn.cursor()
    cursor.execute(sql)

    # Sütun adlarýný al
    column_names = [col[0] for col in cursor.description]

    # Verileri oku ve LOB verilerini uygun þekilde dönüþtür
    data = []
    for row in cursor:
        processed_row = []
        for idx, value in enumerate(row):
            if isinstance(value, oracledb.LOB):
                processed_row.append(value.read())
            else:
                processed_row.append(value)
        data.append(processed_row)
    
    # DataFrame oluþtur
    df = pd.DataFrame(data, columns=column_names)

    # Baðlantýyý kapat
    oracle_conn.close()
    
    return df

def fetch_data_from_oracle_thick(db_config, table_name):
    conn = BaseHook.get_connection(db_config['connection_id'])

    # Database connection settings
    USERNAME = conn.login
    PASSWORD = conn.password
    DSN = db_config['dsn']
    SCHEMA = db_config['schema_name']

    # Create the connection string
    connection = cx_Oracle.connect(
        USERNAME, 
        PASSWORD, 
        DSN
    )

    # SQL query
    sql = f"SELECT * FROM {SCHEMA}.{table_name}"

    # Fetch the data and convert to a pandas DataFrame
    try:
        # Initialize cursor
        cursor = connection.cursor()
        cursor.arraysize = 10000  # Set cursor array size for efficient data fetching
        cursor.prefetchrows = 10000000  # Set prefetch rows to minimize network round trips

        # Execute query and fetch the data into a DataFrame
        cursor.execute(sql)

        # Get column names
        column_names = [col[0] for col in cursor.description]

        # Read data and handle LOB data appropriately
        data = []
        for row in cursor:
            # Check data for each column
            processed_row = []
            for idx, value in enumerate(row):
                if isinstance(value, cx_Oracle.Timestamp):
                    # Convert Oracle Timestamp to Python datetime
                    try:
                        processed_row.append(value.timestamp())
                    except ValueError:
                        processed_row.append(np.nan)  # Invalid date, mark as NaN
                elif isinstance(value, cx_Oracle.LOB):
                    # LOB data, read as string
                    processed_row.append(value.read())
                else:
                    processed_row.append(value)
            data.append(processed_row)

        df = pd.DataFrame(data, columns=column_names)

    finally:
        # Close the cursor and connection
        cursor.close()
        connection.close()

    return df


def fetch_data_from_postgresql(db_config, table_name):

    conn = BaseHook.get_connection(db_config['connection_id'])
    # Database connection details
    USERNAME = conn.login
    PASSWORD = conn.password
    HOST = db_config['host']
    PORT = db_config['port']
    DATABASE = db_config['database_name']
    
    # Create the connection string
    conn_string = f"dbname='{DATABASE}' user='{USERNAME}' host='{HOST}' port='{PORT}' password='{PASSWORD}'"
    custom_sql = db_config['tables'][table_name].get('custom_sql')

    try:
        # Use psycopg to connect to the database
        connection = psycopg.connect(conn_string)
        try:
            # Set DateStyle to 'ISO, MDY'
            with connection.cursor() as cur:
                cur.execute('SET DateStyle = "ISO, MDY";')
            
            # SQL query
            if custom_sql:
                current_year_month = datetime.now().strftime('%Y%m')
                dynamic_table_name = f"{db_config['schema_name']}.TKI_INTERVAL_DATA_{current_year_month}"
                start_date = datetime.now().replace(day=1, hour=0, minute=0, second=0, microsecond=0).strftime('%Y-%m-%d %H:%M:%S')
                # Format the custom SQL query
                sql = custom_sql.format(table_name=dynamic_table_name, start_date=start_date)
            else:
                # Default SQL query to fetch data
                sql = f"SELECT * FROM {table_name}"
            
            # Fetch data using psycopg cursor
            with connection.cursor() as cursor:
                cursor.execute(sql)
                data = cursor.fetchall()
                
            # Convert fetched data to pandas DataFrame
            df = pd.DataFrame(data)
            
            # Commit transaction (optional)
            connection.commit()
        except Exception as e:
            # Rollback transaction on error
            connection.rollback()
            raise e
        finally:
            # Close connection
            connection.close()
        
        return df
    except psycopg.OperationalError as e:
        # Attempt to reconnect if the connection is lost
        print("Connection lost. Attempting to reconnect...")
        return fetch_data_from_postgresql(db_config, table_name)

def get_postgres_conn_string(config, postgres_info):
    logging.debug(f"Fetching PostgreSQL connection details for: {postgres_info}")
    conn_details = config['PostgreSQL'].get(postgres_info)
    if not conn_details:
        raise ValueError(f"No PostgreSQL connection details found for: {postgres_info}")
    logging.debug(f"PostgreSQL connection details: {conn_details}")
    return f"postgresql://{conn_details['user']}:{conn_details['password']}@{conn_details['host']}:{conn_details['port']}/{conn_details['dbname']}"


def copy_data_to_postgresql(dataset, conn_string: str, schema_name: str, table_name: str, truncate: bool = True):
    encoder = ArrowToPostgresBinaryEncoder(dataset.schema)
    pg_schema = encoder.schema()
    # Column names to lowercase
    cols = [f'"{col_name.lower()}" {col.data_type.ddl()}' for col_name, col in pg_schema.columns]
    ddl = f"CREATE SCHEMA IF NOT EXISTS {schema_name};"
    ddl += f"CREATE UNLOGGED TABLE IF NOT EXISTS {schema_name}.{table_name.lower()} ({','.join(cols)});"
    
    if truncate:
        ddl += f"TRUNCATE TABLE {schema_name}.{table_name.lower()};"

    with psycopg.connect(conn_string) as conn:
        with conn.cursor() as cursor:
            cursor.execute(ddl)
            with cursor.copy(f"COPY {schema_name}.{table_name.lower()} FROM STDIN WITH (FORMAT BINARY)") as copy:
                copy.write(encoder.write_header())
                for batch in dataset.to_batches():
                    converted_batch = convert_timestamps_to_microseconds(batch)
                    copy.write(encoder.write_batch(converted_batch))
                copy.write(encoder.finish())


def fetch_data_from_excel(db_config, table_name):
    """
    Fetch data from an Excel file based on the provided configuration and return it as a pandas DataFrame.
    
    Parameters:
    db_config (dict): Configuration dictionary containing details about the Excel file.
    table_name (str): Name of the table to fetch data from.
    
    Returns:
    pd.DataFrame: DataFrame containing the data from the specified Excel file and table.
    """
    # Construct the file path from the base path and table name
    base_path = db_config.get('file_path')
    if not base_path:
        raise ValueError("Base file path not provided in the configuration.")
    
    file_name = f"{table_name}.csv"
    file_path = os.path.join(base_path, file_name)
    
    # Retrieve sheet name from the table configuration if it exists
    table_config = db_config['tables'].get(table_name, {})
    sheet_name = table_config.get('sheet_name')
    
    try:
        # Read the Excel file into a pandas DataFrame
        if sheet_name:
            df = pd.read_excel(file_path, sheet_name=sheet_name)
        else:
            df = pd.read_excel(file_path)
        
        return df
    except Exception as e:
        print(f"Error reading Excel file: {e}")
        raise





def insert_dataframe_directly(df, conn_string, schema_name, table_name, table_config):
    """
    Inserts data directly from DataFrame to PostgreSQL using psycopg2,
    first truncating the table to ensure it is empty before inserting new data.
    This function ensures all column names are lowercase to match the PostgreSQL case sensitivity rules.
    Allows for using an alternative table name (`new_name`) if specified.
    Inserts data in batches using execute_values for efficient bulk operations.
    """
    # Determine the actual table name to use
    actual_table_name = table_config.get("new_name", table_name).lower()

    with psycopg2.connect(conn_string) as conn:
        with conn.cursor() as cursor:
            # Truncate the table before inserting new data
            truncate_query = f"TRUNCATE TABLE {schema_name}.{actual_table_name}"
            cursor.execute(truncate_query)
            conn.commit()  # Confirm TRUNCATE operation
    
            # Generate INSERT INTO statement with lowercase column names
            columns = ', '.join([f'"{col.lower()}"' for col in df.columns])
            insert_query = f"INSERT INTO {schema_name}.{actual_table_name} ({columns}) VALUES %s"

            # Convert DataFrame to list of tuples
            data_tuples = list(df.itertuples(index=False, name=None))

            # Execute the insertion in batches using execute_values
            psycopg2.extras.execute_values(
                cursor, 
                insert_query, 
                data_tuples, 
                page_size=1000  # Using a page size of 1000 as requested
            )
            conn.commit()  # Confirm the INSERT operation

def convert_df_to_parquet(df, table_name, parquet_file_path):
    table = pa.Table.from_pandas(df)
    new_fields = []

    for field in table.schema:
        if field.type == pa.null():
            new_field = pa.field(field.name, pa.string())
        elif pa.types.is_timestamp(field.type):
            new_field = pa.field(field.name, pa.timestamp('us'))
        else:
            new_field = field
        new_fields.append(new_field)

    new_schema = pa.schema(new_fields)
    table_with_new_schema = table.cast(new_schema)
    pq.write_table(table_with_new_schema, parquet_file_path)
    
    # Parquet dosyasýnýn oluþturulduðuna dair bir log mesajý yazdýrýn
    logging.info(f"Parquet dosyasý baþarýyla oluþturuldu: {parquet_file_path}")
    
    return parquet_file_path



def convert_timestamps_to_microseconds(batch):
    new_columns = []
    for i, column in enumerate(batch.schema):
        if pa.types.is_timestamp(column.type):
            # 'us' çözünürlüðü ile UTC zaman dilimine sahip timestamp tipine dönüþtür
            converted_column = batch.column(i).cast(pa.timestamp('us', tz='UTC'))
            new_columns.append(converted_column)
        else:
            new_columns.append(batch.column(i))
    return pa.RecordBatch.from_arrays(new_columns, schema=batch.schema)


def type_transformations(df, table_config):
    if "transformations" in table_config:
        for col, transformation in table_config["transformations"].items():
            if transformation.startswith("CAST(") and transformation.endswith(" AS INTEGER)"):
                # Apply casting operation using SQL-style cast
                column_name = transformation.split("CAST(")[-1].split(" AS ")[0]
                df[col] = df[col].astype(int)
            elif transformation.startswith("CAST(") and transformation.endswith(" AS BOOLEAN)"):
                # Apply casting operation to boolean type
                column_name = transformation.split("CAST(")[-1].split(" AS ")[0]
                df[col] = df[col].astype(bool)
            elif transformation == "datetime_to_date":
                # Convert datetime columns to date
                df[col] = pd.to_datetime(df[col]).dt.date    
            else:
                # Apply other transformations if any
                df[col] = df[col].apply(eval(transformation))
    return df



def apply_transformations(df, column_mapping):
    # Sütun isimlerini deðiþtir
    rename_dict = {
        key: value for key, value in column_mapping.items() if key in df.columns and not key.startswith('Mathematical.') and not key.startswith('TalendDate.')
    }
    df.rename(columns=rename_dict, inplace=True)
    
    # Özel dönüþümleri uygula
    for original, new in column_mapping.items():
        if original.startswith("Mathematical.INT('") and original.endswith("')"):
            # 'Mathematical.INT('1')' gibi ifadeler için tüm sütun deðerlerini sabit bir deðere ayarla
            fixed_value = int(original.split("'")[1])  # '1' veya '0' olarak ayarlanmýþ deðeri al
            df[new] = fixed_value  # Tüm sütun deðerlerini bu sabit deðer ile doldur
        elif original.startswith('TalendDate.getCurrentDate'):
            df[new] = datetime.now()
        elif original.startswith('TalendDate.getCurrentMonth'):
            current_month = datetime.now().strftime('%Y%m')
            df[new] = current_month

    return df


def convert_lob_to_string(val):
    return val.read() if isinstance(val, oracledb.LOB) else val

    

def remove_invalid_bytes(value):
    if isinstance(value, str):
        # NULL baytlarýný kaldýr
        cleaned_value = value.replace('\x00', '')
        return cleaned_value
    return value

def clean_specific_columns(df, table_name, table_config):
    clean_columns = table_config.get(table_name, {}).get("clean_columns", [])
    for column_name in df.columns:
        if column_name in clean_columns:
            # Sadece belirtilen sütun adlarýnda geçersiz baytlarý temizle
            df[column_name] = df[column_name].apply(remove_invalid_bytes)
    return df


def convert_to_date(value):
    """ Timestamp formatýndaki veriyi date formatýna çevirir. """
    if pd.notna(value):
        return pd.to_datetime(value).date()
    return value

def clean_date_columns(df, table_name, table_config):
    """ Belirli sütunlardaki tarih-saat verilerini sadece tarih bilgisine dönüþtürür. """
    column_config = table_config.get(table_name, {}).get("date_columns", [])
    for column_name in column_config:
        if column_name in df.columns:
            df[column_name] = df[column_name].apply(convert_to_date)
    return df    

def convert_to_timestampz(value):
    """ Converts the timestamp data in Timestamp format to the timestampz format with UTC timezone. """
    if pd.notna(value):
        value = pd.to_datetime(value)
        if value.tzinfo is None:
            return value.tz_localize('UTC')
        else:
            return value
    return value

def clean_timestamp_columns(df, table_name, table_config):
    """ Converts date-time data in specific columns to timestampz format with UTC timezone. """
    timestamp_config = table_config.get(table_name, {}).get("timestamp_columns", [])
    for column_name in timestamp_config:
        if column_name in df.columns:
            df[column_name] = df[column_name].apply(convert_to_timestampz)
    return df

def convert_datetimeoffset_columns(df, datetimeoffset_columns):
    for column in datetimeoffset_columns:
        if column in df.columns:
            # datetimeoffset türündeki sütunlarý timestamp with time zone türüne dönüþtür
            df[column] = pd.to_datetime(df[column]).dt.tz_localize(None)  
    return df