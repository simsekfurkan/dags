# transformations.py

import pandas as pd
from datetime import datetime
import geopandas as gpd
import oracledb
import numpy as np



def convert_geometry(df):
    if 'GEOLOC' in df.columns:
        # Set the entire 'GEOLOC' column to None if it contains SDO_GEOMETRY objects
        df['GEOLOC'] = df['GEOLOC'].apply(lambda geom: None if isinstance(geom, oracledb.DbObject) else geom)
    return df


def convert_nan_to_null(df):
    """
    Converts NaN values in DataFrame to None.
    
    Parameters:
        df (DataFrame): Input DataFrame
    
    Returns:
        DataFrame: DataFrame with NaN values converted to None
    """
    return df.where(pd.notnull(df), None)    

def clean_columns(df, columns_to_clean):
    for column in columns_to_clean:
        if column in df.columns:
            df[column] = df[column].apply(lambda x: x.replace('\x00', '') if isinstance(x, str) else x)
        else:
            print(f"Column {column} does not exist in DataFrame")
    return df

def convert_to_date(df, columns):
    for column in columns:
        df[column] = pd.to_datetime(df[column]).dt.date
    return df

def date_to_NaT(df, date_columns):
    """Convert specified columns in the dataframe to datetime."""
    for col in date_columns:
        df[col] = pd.to_datetime(df[col], errors='coerce')
    return df    

def convert_to_timestamp(value):
    """ Converts the date-time data to Pandas Timestamp format without timezone information. """
    if pd.notna(value):
        return pd.to_datetime(value)  # Automatically converts to Timestamp without timezone
    return value

def clean_timestamp_columns(df, table_name, table_config):
    """ Applies the conversion to timestamp format for specified columns. """
    timestamp_config = table_config.get(table_name, {}).get("timestamp_columns", [])
    for column_name in timestamp_config:
        if column_name in df.columns:
            df[column_name] = df[column_name].apply(convert_to_timestamp)
    return df

def convert_datetimeoffset_columns(df, datetimeoffset_columns):
    for column in datetimeoffset_columns:
        if column in df.columns:
            # datetimeoffset türündeki sütunlarý timestamp with time zone türüne dönüþtür
            df[column] = pd.to_datetime(df[column]).dt.tz_localize(None)  
    return df

def convert_to_iso_format(df, date_columns):
    """Convert date columns to ISO format (YYYY-MM-DD)."""
    for col in date_columns:
        df[col] = pd.to_datetime(df[col], format='%d/%m/%Y').dt.strftime('%Y-%m-%d')
    return df   

def trim_columns(df, columns):
    for column in columns:
        if column in df.columns:
            df[column] = df[column].str.strip()  # Trim whitespace
            df[column] = df[column].replace('', np.nan)  # Replace empty strings with NaN
        else:
            print(f"Warning: Column '{column}' not found in DataFrame.")
    return df  

def apply_general_transformations(df, table_name, table_config):
    if 'clean_columns' in table_config:
        df = clean_columns(df, table_config['clean_columns'])
    if 'date_columns' in table_config:
        df = convert_to_date(df, table_config['date_columns'])
    if 'timestamp_columns' in table_config:
        df = clean_timestamp_columns(df, table_name, table_config)
    if 'iso_date_columns' in table_config:
        df = convert_to_iso_format(df, table_config['iso_date_columns'])    
    if 'is_date' in table_config:
        df = date_to_NaT(df, table_config['is_date'])
    if 'trim_columns' in table_config:
        df = trim_columns(df, table_config['trim_columns'])
    return df

    

def apply_special_transformations(df, column_mapping):
    # Normal yeniden adlandýrma için bir sözlük oluþtur
    rename_dict = {
        key: value for key, value in column_mapping.items() 
        if key in df.columns and not isinstance(value, list)
        and not key.startswith('Mathematical.') and not key.startswith('TalendDate.')
    }
    df.rename(columns=rename_dict, inplace=True)
    
    # Özel dönüþümleri uygula
    for original, new in column_mapping.items():
        if isinstance(new, list) and len(new) == 2:
            # Birden fazla yeni isim için kolonlarý kopyala
            df[new[0]] = df[original]
            df[new[1]] = df[original]
        elif isinstance(new, list):
            raise ValueError(f"{original} kolonu için desteklenmeyen yeni isim sayýsý: {new}")
        elif original.startswith("Mathematical.INT('") and original.endswith("')"):
            # 'Mathematical.INT('1')' gibi ifadeler için tüm sütun deðerlerini sabit bir deðere ayarla
            fixed_value = int(original.split("'")[1])  # '1' veya '0' olarak ayarlanmýþ deðeri al
            df[new] = fixed_value  # Tüm sütun deðerlerini bu sabit deðer ile doldur
        elif original.startswith('TalendDate.getCurrentDate'):
            df[new] = datetime.now()
        elif original.startswith('TalendDate.getCurrentMonth'):
            current_month = datetime.now().strftime('%Y%m')
            df[new] = current_month

    return df
