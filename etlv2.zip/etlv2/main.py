from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from datetime import datetime
import json
from etlv2.csv_transfer import  copy_csv_to_postgresql, export_to_csv
from etlv2.data_fetcher import    fetch_data_from_excel, fetch_data_from_oracle, fetch_data_from_oracle_thick, fetch_data_from_postgresql, fetch_data_from_sqlserver, get_postgres_conn_string, copy_data_to_postgresql, convert_df_to_parquet, insert_dataframe_directly, type_transformations
import pyarrow.dataset as ds
from etlv2.transformations import convert_nan_to_null, apply_general_transformations, apply_special_transformations,convert_datetimeoffset_columns, convert_geometry
from airflow.hooks.base_hook import BaseHook


# Yapýlandýrma dosyalarýný yükleme
with open('dags/etlv2/db_config.json', 'r') as db_f, open('dags/etlv2/etl_plans.json', 'r') as plan_f:
    db_config = json.load(db_f)
    etl_plans = json.load(plan_f)

default_args = {
    "owner": "airflow",
    "start_date": datetime(2024, 4, 15),
    "retries": 0,
}




def process_and_copy_table(db_config, database, table_name, **kwargs):
    # Extract specific database details
    db_details = db_config[database]
    postgres_schema = db_details.get("postgresql_schema", "default_schema")
    postgres_info = db_details.get("postgresql_info", "default_pool")
    table_config = db_details["tables"][table_name]
    new_name = table_config.get("new_name", table_name.lower())
    schema_name = db_details["schema_name"]
    csv_transfer_enabled = db_details.get("csv_transfer", False)
    postgres_conn_string = get_postgres_conn_string(db_config, postgres_info)
    oracle_connection_string = None
    sqlserver_connection_string = None
    conn = BaseHook.get_connection(db_details['connection_id'])
    user = conn.login
    password = conn.password

    # Depending on the type, construct the Oracle or SQL Server connection string
    if db_details["type"] == "oracle":
        dsn = db_details.get("dsn")
        if not dsn:
            raise ValueError("DSN is required for Oracle database configurations")
        oracle_connection_string = f'{user}/{password}@{dsn}'
    elif db_details["type"] == "sqlserver":
        server = db_details.get("server")
        port = db_details.get("port")
        database_name = db_details.get("database")
        if not all([server, port, database_name]):
            raise ValueError("Server, port, and database are required for SQL Server configurations")
        sqlserver_connection_string = f"DRIVER={{ODBC Driver 18 for SQL Server}};SERVER={server},{port};DATABASE={database_name};UID={user};PWD={password};TrustServerCertificate=Yes;"
    elif db_details["type"] == "postgresql":
        df = fetch_data_from_postgresql(db_details, table_name)
    elif db_details["type"] == "oracle-thick":
        df = fetch_data_from_oracle_thick(db_details, table_name)
    elif db_details["type"] == "excel":
        df = fetch_data_from_excel(db_details, table_name)
    else:
        raise ValueError("Unsupported database type")

    if csv_transfer_enabled:
        csv_folder = 'dags/etlv2/csv_files'
        connection_string = oracle_connection_string if db_details["type"] == "oracle" else sqlserver_connection_string
        if connection_string is None:
            raise ValueError("Appropriate connection string is not available for CSV export.")
        csv_file_path = export_to_csv(connection_string, schema_name, table_name, csv_folder, db_details)
        copy_csv_to_postgresql(csv_file_path, postgres_conn_string, postgres_schema, new_name)
        
    else:
        fetch_func = fetch_data_from_oracle if db_details["type"] == "oracle" else fetch_data_from_sqlserver
        if db_details["type"] == "oracle-thick":
            fetch_func = fetch_data_from_oracle_thick
        elif db_details["type"] == "postgresql":
            fetch_func = fetch_data_from_postgresql
        elif db_details["type"] == "excel":
            fetch_func = fetch_data_from_excel
        
        df = fetch_func(db_details, table_name)
        
        # Apply transformations
        df = convert_nan_to_null(df)
        df = convert_geometry(df)
        df = type_transformations(df, table_config)
        df = apply_general_transformations(df, table_name, table_config)
        df = apply_special_transformations(df, table_config.get('column_mapping', {}))
        df = convert_datetimeoffset_columns(df, table_config.get('datetimeoffset_columns', []))
        
        if not db_details.get("not_bulk", False):
            parquet_file_path = f'dags/etlv2/parquet_files/{new_name}.parquet'
            convert_df_to_parquet(df, table_name, parquet_file_path)
            dataset = ds.dataset(parquet_file_path, format='parquet')
            copy_data_to_postgresql(dataset, postgres_conn_string, postgres_schema, new_name)
        else:
            insert_dataframe_directly(df, postgres_conn_string, postgres_schema, new_name, table_config)


# Her plan için bir DAG oluþturma
for plan_name, plan_details in etl_plans.items():
    dag = DAG(
        f'ETL_LP_{plan_name}',
        default_args=default_args,
        description=f'ETL Plan {plan_name}',
        schedule_interval=plan_details['zamanlama'],
        catchup=False,
        max_active_runs=64,
        max_active_tasks=128
    )

    with dag:
        for db_name in plan_details['veritabanlari']:
            db_details = db_config[db_name]
            for table_name in db_details.get("tables", {}):
                task = PythonOperator(
                    task_id=f'{db_name}_process_{table_name}',
                    python_callable=process_and_copy_table,
                    op_kwargs={'db_config': db_config,'database': db_name, 'table_name': table_name},
                )

    globals()[f'dag_{plan_name}'] = dag
